These files are the precomputed B-field for a bar magnet.
See BarMagnet.java and Unfuddle #2236 for details.
The data sets were computed using MathCAD, see faraday/doc/bFieldOfHorizCylinerNumerical.*
